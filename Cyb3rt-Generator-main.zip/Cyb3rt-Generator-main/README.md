
# Free Accounts Generator

With this script you can generate : NordVPN, Disney+, Spotify, Netflix..... accounts.

Do not sell this script !!

ou should only use this frame for legal inspection agreed by both parties, or for educational purposes, I am not responsible for any damage caused by you caused by the generator.






## Authors

- [@cyb3rt123](https://github.com/cyb3rt123)


## Installation

Use my project with nodejs

```bash
  sudo apt update
  sudo apt install nodejs npm
  node -v

  Output
  v10.15.2
```
    
## Screenshots

![App Screenshot](https://i.postimg.cc/JnmKtzYY/Screenshot-6.png)

