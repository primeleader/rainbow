<h1 align="center">Prodigy Hack</h1>
<h3 align="center">One of the best Prodigy hacks.</h3>
<h2 align="center">Discord Support Server: https://discord.gg/abqMVbDanB</h2>

#### Made by rxzyx (rzx). This is purley for education purposes.
- 📫 Have a problem? **Just write an issue and I will do my best to respond.**

## Features:

- **Get Gold**
- **Set User Level**
- **Unlock All Items (Unlock All Furniture Included)**
- **Unlock All Pets**
- **Health Hack**
- **Unlimited Damage**
- **Unlimited Health**
- **Walk Anywhere**
- **Set Walk Speed**
- **Fill Energy**
- **Free Membership**
- **Unlimited Spins**
- **Set Grade**
- **Set Tower**
- **Reset Account**
- **Skip Tutorial**
- **Spam Effects On People**
- **Morph Forever**
## 🤖 Features with Problems (will be fixed soon):

- None for now, report to Issues if you find an issue!

#### I am not responsible for your actions with these cheats.

## How To Use:

- Simply open the file that sounds more interesting, click the "Raw" button, then copy the code and paste it into the chrome console when you're on prodigy.

<h3 align="left">Made With JavaScript:</h3>
<p align="left"> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> </p>

#### Copyright &copy; 2022 rzx.
